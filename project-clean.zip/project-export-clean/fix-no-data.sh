#!/bin/bash

echo "=========================================="
echo "   Diagnosing 'No Data' Issue"
echo "=========================================="
echo ""

# Check backend
echo "1. Checking backend..."
BACKEND_RESPONSE=$(curl -s http://localhost:8000/stats/today 2>&1)
if echo "$BACKEND_RESPONSE" | grep -q "received_today"; then
    echo "   ✅ Backend is running and returning data"
    echo "   📊 Sample data: $(echo "$BACKEND_RESPONSE" | grep -o '"received_today":[0-9]*' | head -1)"
else
    echo "   ❌ Backend is NOT responding"
    echo "   💡 Run: ./start-backend.sh"
    exit 1
fi
echo ""

# Check frontend
echo "2. Checking frontend..."
FRONTEND_RESPONSE=$(curl -s http://localhost:3000 2>&1 | head -1)
if echo "$FRONTEND_RESPONSE" | grep -q "html\|DOCTYPE"; then
    echo "   ✅ Frontend is running"
else
    echo "   ❌ Frontend is NOT responding"
    echo "   💡 Run: ./start-frontend.sh"
    exit 1
fi
echo ""

# Check environment variable
echo "3. Checking API configuration..."
if [ -f "frontend/.env.local" ]; then
    API_URL=$(grep "NEXT_PUBLIC_API_URL" frontend/.env.local | cut -d'=' -f2)
    if [ -z "$API_URL" ]; then
        echo "   ⚠️  NEXT_PUBLIC_API_URL not set in frontend/.env.local"
        echo "   💡 Setting it to http://localhost:8000..."
        echo "NEXT_PUBLIC_API_URL=http://localhost:8000" >> frontend/.env.local
        echo "   ✅ Fixed! Restart frontend: ./start-frontend.sh"
    else
        echo "   ✅ API URL is set: $API_URL"
        if [ "$API_URL" != "http://localhost:8000" ]; then
            echo "   ⚠️  API URL points to: $API_URL"
            echo "   💡 If running locally, it should be: http://localhost:8000"
        fi
    fi
else
    echo "   ⚠️  frontend/.env.local not found"
    echo "   💡 Creating it with http://localhost:8000..."
    echo "NEXT_PUBLIC_API_URL=http://localhost:8000" > frontend/.env.local
    echo "   ✅ Created! Restart frontend: ./start-frontend.sh"
fi
echo ""

# Check if deployed version
echo "4. Are you using the deployed version (Vercel)?"
echo "   If YES, you need to set NEXT_PUBLIC_API_URL in Vercel dashboard:"
echo "   - Go to: https://vercel.com/dashboard"
echo "   - Your project → Settings → Environment Variables"
echo "   - Add: NEXT_PUBLIC_API_URL = https://YOUR_RAILWAY_URL.up.railway.app"
echo "   - Redeploy"
echo ""

echo "=========================================="
echo "   Quick Fixes:"
echo "=========================================="
echo ""
echo "If running LOCALLY:"
echo "  1. Make sure backend is running: ./start-backend.sh"
echo "  2. Make sure frontend is running: ./start-frontend.sh"
echo "  3. Check frontend/.env.local has: NEXT_PUBLIC_API_URL=http://localhost:8000"
echo "  4. Restart frontend if you changed .env.local"
echo ""
echo "If using DEPLOYED version (Vercel):"
echo "  1. Get your Railway backend URL"
echo "  2. Add NEXT_PUBLIC_API_URL in Vercel → Settings → Environment Variables"
echo "  3. Redeploy on Vercel"
echo ""
echo "=========================================="
