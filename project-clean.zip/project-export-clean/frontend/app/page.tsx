'use client';

import { useEffect } from 'react';
import { useRouter, usePathname } from 'next/navigation';
import LoadingSpinner from '@/components/LoadingSpinner';

export default function Home() {
  const router = useRouter();
  const pathname = usePathname();

  useEffect(() => {
    // Only redirect if we're actually on the root path
    if (pathname === '/') {
      router.replace('/scan');
    }
  }, [pathname, router]);

  // Show loading while redirecting
  if (pathname === '/') {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <LoadingSpinner size="lg" />
      </div>
    );
  }

  return null;
}
