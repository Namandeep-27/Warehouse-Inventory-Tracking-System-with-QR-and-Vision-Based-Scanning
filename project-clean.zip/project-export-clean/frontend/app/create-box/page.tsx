'use client';

import { useState, useEffect, useMemo, useRef } from 'react';
import { toast } from 'react-hot-toast';
import Select from 'react-select';
import { createBox, getProducts } from '@/lib/api';
import { Product, Box } from '@/lib/types';
import BoxLabelPrint from '@/components/BoxLabelPrint';
import { useUserRole } from '@/contexts/UserRoleContext';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { motion } from 'framer-motion';
import { Package, Maximize2, Info } from 'lucide-react';
import { cn } from '@/lib/utils';
import LoadingSpinner from '@/components/LoadingSpinner';
import PageTransition from '@/components/PageTransition';
import PageHeader from '@/components/PageHeader';
import CategoryFilter, { ProductCategory, getProductCategory } from '@/components/CategoryFilter';

export default function CreateBoxPage() {
  const { isAdmin, isLoading } = useUserRole();
  const router = useRouter();
  const [products, setProducts] = useState<Product[]>([]);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [lotCode, setLotCode] = useState('');
  const [loading, setLoading] = useState(false);
  const [productsLoading, setProductsLoading] = useState(true);
  const [createdBox, setCreatedBox] = useState<Box | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [menuIsOpen, setMenuIsOpen] = useState(false);
  const isChangingCategoryRef = useRef(false);
  const categoryFilterRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (isLoading) return; // Wait for role to load
    
    if (!isAdmin) {
      router.push('/scan');
      return;
    }
    loadProducts();
  }, [isAdmin, isLoading, router]);

  // Listen for clicks to detect if category filter was clicked
  useEffect(() => {
    const handleDocumentClick = (e: MouseEvent) => {
      const target = e.target as HTMLElement;
      // Check if click was on a category button
      if (categoryFilterRef.current && categoryFilterRef.current.contains(target)) {
        // Category filter was clicked - keep menu open if it was open
        if (menuIsOpen) {
          isChangingCategoryRef.current = true;
          setTimeout(() => {
            setMenuIsOpen(true);
            setTimeout(() => {
              isChangingCategoryRef.current = false;
            }, 200);
          }, 0);
        }
      }
    };

    document.addEventListener('mousedown', handleDocumentClick, true);
    return () => {
      document.removeEventListener('mousedown', handleDocumentClick, true);
    };
  }, [menuIsOpen]);

  const loadProducts = async () => {
    try {
      setProductsLoading(true);
      const data = await getProducts();
      setProducts(data);
    } catch (error: any) {
      toast.error('Failed to load products');
    } finally {
      setProductsLoading(false);
    }
  };

  const handleCreateBox = async () => {
    if (!selectedProduct) {
      toast.error('Please select a product');
      return;
    }

    setLoading(true);
    try {
      const box = await createBox({
        product_id: selectedProduct.product_id,
        lot_code: lotCode || undefined,
      });
      setCreatedBox(box);
      toast.success('Box label generated successfully');
    } catch (error: any) {
      toast.error(error.response?.data?.detail || 'Failed to create box');
    } finally {
      setLoading(false);
    }
  };

  // Filter products by category and search - MUST be before early return
  const filteredProducts = useMemo(() => {
    return products.filter((product) => {
      // Category filter
      if (selectedCategory !== 'all') {
        const productCategory = getProductCategory(product.name, product.brand);
        if (productCategory !== selectedCategory) {
          return false;
        }
      }
      
      // Search filter
      if (searchQuery) {
        const query = searchQuery.toLowerCase();
        const searchText = `${product.brand} ${product.name} ${product.size || ''}`.toLowerCase();
        if (!searchText.includes(query)) {
          return false;
        }
      }
      
      return true;
    });
  }, [products, selectedCategory, searchQuery]);

  const productOptions = filteredProducts.map((p) => ({
    value: p.product_id,
    label: `${p.brand} - ${p.name}${p.size ? ` (${p.size})` : ''}`,
    product: p,
  }));

  // Handle category change while preserving menu open state
  const handleCategoryChange = (category: ProductCategory) => {
    const wasOpen = menuIsOpen;
    if (wasOpen) {
      // Set flag BEFORE changing category to prevent menu close
      isChangingCategoryRef.current = true;
    }
    setSelectedCategory(category);
    // Keep menu open if it was open before category change
    if (wasOpen) {
      // Force menu to stay open - use multiple strategies
      setMenuIsOpen(true);
      // Use requestAnimationFrame and setTimeout to ensure it stays open
      requestAnimationFrame(() => {
        setMenuIsOpen(true);
        setTimeout(() => {
          setMenuIsOpen(true);
          // Reset flag after menu should be stable
          setTimeout(() => {
            isChangingCategoryRef.current = false;
          }, 300);
        }, 10);
      });
    } else {
      isChangingCategoryRef.current = false;
    }
  };

  // Early return AFTER all hooks
  if (!isAdmin) {
    return null;
  }

  return (
    <PageTransition>
      <div className="max-w-4xl mx-auto">
        <PageHeader
          title="Create Box Label"
          subtitle="Generate printable QR code labels for physical boxes. Each label includes a unique box ID that can be scanned throughout the warehouse workflow."
        />

        <motion.div
          className="bg-blue-50 border-2 border-blue-200 rounded-2xl p-6 mb-8 shadow-sm"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1, duration: 0.3 }}
        >
          <div className="flex items-start gap-4">
            <div className="p-2 bg-blue-100 rounded-lg">
              <Info className="w-5 h-5 text-blue-600 flex-shrink-0" />
            </div>
            <div className="flex-1">
              <p className="font-semibold mb-2 text-blue-900">How to create a box label:</p>
              <ol className="list-decimal list-inside space-y-1.5 text-sm text-blue-800">
                <li>Select the product this box will contain</li>
                <li>Optionally add a lot code if tracking by batch</li>
                <li>Click "Generate Box Label" to create the label</li>
                <li>Print the label and attach it to the physical box</li>
                <li>Once attached, scan the label when receiving the box into inventory</li>
              </ol>
            </div>
          </div>
        </motion.div>

        <motion.div
          className="bg-white p-8 rounded-2xl shadow-lg border border-slate-200 mb-8"
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2, duration: 0.3 }}
        >
          <div className="mb-6">
            <label className="block text-sm font-semibold text-slate-700 mb-3 flex items-center gap-2">
              <Package className="w-4 h-4" />
              Product <span className="text-red-500">*</span>
            </label>
            
            {/* Category Filter */}
            {!productsLoading && products.length > 0 && (
              <div 
                ref={categoryFilterRef}
                className="mb-4"
                style={{ position: 'relative', zIndex: 1 }}
                onMouseDown={(e) => {
                  // Aggressively prevent react-select from closing
                  e.preventDefault();
                  e.stopPropagation();
                  e.nativeEvent.stopImmediatePropagation();
                }}
                onClick={(e) => {
                  e.stopPropagation();
                  e.nativeEvent.stopImmediatePropagation();
                }}
                onTouchStart={(e) => {
                  // Also handle touch events for mobile
                  e.stopPropagation();
                }}
              >
                <CategoryFilter
                  selectedCategory={selectedCategory}
                  onCategoryChange={handleCategoryChange}
                  className="mb-3"
                />
                <input
                  type="text"
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  placeholder="Search products by brand, name, or size..."
                  className="w-full px-4 py-2.5 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all text-sm"
                />
                {selectedCategory === 'all' && !searchQuery ? (
                  <p className="mt-2 text-xs text-slate-500">
                    {products.length} {products.length === 1 ? 'product' : 'products'} available
                  </p>
                ) : filteredProducts.length !== products.length ? (
                  <p className="mt-2 text-xs text-slate-500">
                    Showing {filteredProducts.length} of {products.length} products
                  </p>
                ) : null}
              </div>
            )}
            
            {productsLoading ? (
              <LoadingSpinner size="md" />
            ) : (
              <Select
                options={productOptions}
                onChange={(option) => {
                  setSelectedProduct(option?.product || null);
                  setMenuIsOpen(false); // Close menu when product is selected
                }}
                onMenuOpen={() => {
                  isChangingCategoryRef.current = false;
                  setMenuIsOpen(true);
                }}
                onMenuClose={() => {
                  // Don't close if we're in the middle of changing category
                  if (isChangingCategoryRef.current) {
                    // Immediately force menu to stay open
                    requestAnimationFrame(() => {
                      setMenuIsOpen(true);
                    });
                    return;
                  }
                  setMenuIsOpen(false);
                }}
                menuIsOpen={menuIsOpen}
                placeholder={filteredProducts.length === 0 ? "No products match filters..." : "Select a product..."}
                isSearchable
                className="react-select-container"
                classNamePrefix="react-select"
                menuShouldBlockScroll={false}
                menuPortalTarget={typeof document !== 'undefined' ? document.body : null}
                menuPosition="fixed"
              />
            )}
            {products.length === 0 && !productsLoading && (
              <p className="mt-2 text-sm text-slate-600">
                No products found. <Link href="/products" className="text-blue-600 hover:text-blue-800 font-medium">Create a product first</Link>.
              </p>
            )}
            {products.length > 0 && filteredProducts.length === 0 && !productsLoading && (
              <p className="mt-2 text-sm text-amber-600">
                No products match the selected filters. Try a different category or search term.
              </p>
            )}
          </div>

          <div className="mb-6">
            <label className="block text-sm font-semibold text-slate-700 mb-2">
              Lot Code (Optional)
            </label>
            <input
              type="text"
              value={lotCode}
              onChange={(e) => setLotCode(e.target.value)}
              className="w-full px-4 py-3 border border-slate-300 rounded-xl focus:ring-2 focus:ring-blue-500 focus:border-blue-500 transition-all"
              placeholder="e.g., L2026-01"
            />
            <p className="mt-1.5 text-xs text-slate-500">Use lot codes to track batches or production dates</p>
          </div>

          <motion.button
            onClick={handleCreateBox}
            disabled={loading || !selectedProduct}
            className={cn(
              'w-full px-6 py-3.5 bg-blue-600 text-white rounded-xl',
              'hover:bg-blue-700 disabled:bg-slate-400 disabled:cursor-not-allowed',
              'transition-colors flex items-center justify-center gap-2 font-semibold shadow-lg hover:shadow-xl'
            )}
            whileHover={{ scale: loading || !selectedProduct ? 1 : 1.02 }}
            whileTap={{ scale: loading || !selectedProduct ? 1 : 0.98 }}
          >
            {loading ? (
              <>
                <LoadingSpinner size="sm" />
                Generating...
              </>
            ) : (
              <>
                <Maximize2 className="w-4 h-4" />
                Generate Box Label
              </>
            )}
          </motion.button>
        </motion.div>

        {createdBox && (
          <motion.div
            className="bg-white p-8 rounded-2xl shadow-lg border border-slate-200"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="mb-6">
              <h2 className="text-2xl font-bold text-slate-900 mb-2">Generated Label</h2>
              <p className="text-sm text-slate-600">Print this label and attach it to the physical box</p>
            </div>
            <BoxLabelPrint
              boxId={createdBox.box_id}
              qrValue={createdBox.qr_value}
              product={createdBox.product}
              lotCode={createdBox.lot_code}
            />
          </motion.div>
        )}
      </div>
    </PageTransition>
  );
}
