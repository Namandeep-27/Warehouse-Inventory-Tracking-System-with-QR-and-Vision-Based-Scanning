'use client';

import { useState, useEffect, useRef } from 'react';
import { toast } from 'react-hot-toast';
import QRScanner from '@/components/QRScanner';
import WorkStatusBanner from '@/components/WorkStatusBanner';
import PutawayTaskList from '@/components/PutawayTaskList';
import RecentActivityFeed from '@/components/RecentActivityFeed';
import WorkflowMetrics from '@/components/WorkflowMetrics';
import ScanConfirmationCard from '@/components/ScanConfirmationCard';
import PageHeader from '@/components/PageHeader';
import ActionCard from '@/components/ActionCard';
import LocationOccupancyDialog from '@/components/LocationOccupancyDialog';
import { Mode, Location, BoxDetails, Event } from '@/lib/types';
import { createEvent, undoEvent, getBox, getLocations, getLocationOccupancy, LocationOccupancy } from '@/lib/api';
import { motion, AnimatePresence } from 'framer-motion';
import { XCircle, Download, Upload, Move, Camera, RotateCcw, ArrowLeft, ArrowRight, QrCode, MapPin, Package } from 'lucide-react';
import PageTransition from '@/components/PageTransition';
import { cn } from '@/lib/utils';
import { useStats } from '@/hooks/useStats';
import { useRouter } from 'next/navigation';

export default function ScanPage() {
  const [mode, setMode] = useState<Mode | null>(null);
  const [cameraActive, setCameraActive] = useState(false);
  const [pendingLocation, setPendingLocation] = useState<Location | null>(null);
  const [pendingLocationCode, setPendingLocationCode] = useState<string | null>(null);
  const [moveStep, setMoveStep] = useState<1 | 2>(1);
  const [lastEvent, setLastEvent] = useState<Event | null>(null);
  const [lastEventId, setLastEventId] = useState<string | null>(null);
  const [boxDetails, setBoxDetails] = useState<BoxDetails | null>(null);
  const { stats, refresh: refreshStats } = useStats();
  const router = useRouter();
  const toPutAway = stats?.to_put_away ?? 0;
  const processingBoxRef = useRef<Set<string>>(new Set());
  // Use a ref to track if we should preserve the confirmation card
  // This prevents it from being cleared by re-renders or state updates
  const shouldPreserveConfirmationRef = useRef(false);
  const [occupancyDialogOpen, setOccupancyDialogOpen] = useState(false);
  const [occupancy, setOccupancy] = useState<LocationOccupancy | null>(null);
  const [checkingOccupancy, setCheckingOccupancy] = useState(false);
  const [pendingLocationForOccupancy, setPendingLocationForOccupancy] = useState<Location | null>(null);
  const [lastScannedType, setLastScannedType] = useState<'box' | 'location' | null>(null);
  const [lastScannedValue, setLastScannedValue] = useState<string | null>(null);
  const [wrongScanTypeWarning, setWrongScanTypeWarning] = useState<{ expected: 'box' | 'location'; received: 'box' | 'location' } | null>(null);
  const [scannedBoxPreview, setScannedBoxPreview] = useState<BoxDetails | null>(null);
  const [isFetchingPreview, setIsFetchingPreview] = useState(false);

  // Stats are now fetched via useStats hook - no need for separate fetch

  useEffect(() => {
    // Reset when mode changes
    // CRITICAL: Never clear lastEvent here - we need it for the confirmation card
    if (mode !== 'MOVE') {
      setPendingLocation(null);
      setPendingLocationCode(null);
      setMoveStep(1);
    } else {
      setMoveStep(1);
      setPendingLocation(null);
      setPendingLocationCode(null);
    }
    // Reset camera when mode changes (but keep lastEvent for confirmation card)
    setCameraActive(false);
    // Don't clear lastEventId - we need it for undo functionality
    // Only clear it when explicitly dismissing or undoing
  }, [mode]);

  // CRITICAL: If we have a lastEvent but mode is null, restore mode from the event
  // This prevents the home screen from showing when confirmation card should be visible
  // Removed useEffect that was causing "Cannot transition to a new state" error
  // Mode is now always set synchronously in handleBoxScan, so this fallback is not needed
  // and was causing conflicts with the synchronous setMode call
  

  const handleModeSelect = (selectedMode: Mode) => {
    // #region agent log
    fetch('http://127.0.0.1:7242/ingest/8e87de8d-f5e1-403b-bce8-12dabf8097c0',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'scan/page.tsx:87',message:'handleModeSelect: Called',data:{selectedMode,currentMode:mode,shouldPreserve:shouldPreserveConfirmationRef.current},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'G'})}).catch(()=>{});
    // #endregion
    // Only clear lastEvent if we're actually changing modes (not just initializing)
    // AND we're not preserving a confirmation card
    if (mode !== null && mode !== selectedMode && !shouldPreserveConfirmationRef.current) {
      // #region agent log
      fetch('http://127.0.0.1:7242/ingest/8e87de8d-f5e1-403b-bce8-12dabf8097c0',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'scan/page.tsx:91',message:'handleModeSelect: Clearing lastEvent',data:{reason:'mode change'},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'G'})}).catch(()=>{});
      // #endregion
      setLastEvent(null);
      setLastEventId(null);
      setBoxDetails(null);
    }
    setMode(selectedMode);
    setCameraActive(false);
  };

  const handleStartCamera = () => {
    if (!mode) {
      toast.error('Please select an action first');
      return;
    }
    // #region agent log
    fetch('http://127.0.0.1:7242/ingest/8e87de8d-f5e1-403b-bce8-12dabf8097c0',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'scan/page.tsx:99',message:'handleStartCamera: Called',data:{mode,shouldPreserve:shouldPreserveConfirmationRef.current},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'H'})}).catch(()=>{});
    // #endregion
    // Clear previous scan results when starting a new scan
    // Only clear if user explicitly starts a new scan (not preserving confirmation)
    shouldPreserveConfirmationRef.current = false;
    // #region agent log
    fetch('http://127.0.0.1:7242/ingest/8e87de8d-f5e1-403b-bce8-12dabf8097c0',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'scan/page.tsx:107',message:'handleStartCamera: Clearing lastEvent',data:{reason:'starting new scan'},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'H'})}).catch(()=>{});
    // #endregion
    setLastEvent(null);
    setLastEventId(null);
    setBoxDetails(null);
    setScannedBoxPreview(null);
    // Reset MOVE mode state if starting a new scan
    if (mode === 'MOVE') {
      setPendingLocation(null);
      setPendingLocationCode(null);
      setMoveStep(1);
    }
    setCameraActive(true);
  };

  const handleStopCamera = () => {
    setCameraActive(false);
  };

  const handleLocationScan = async (locationCode: string) => {
    if (pendingLocationCode === locationCode) {
      return;
    }

    try {
      // Fetch location details
      const locations = await getLocations();
      const location = locations.find((loc) => loc.location_code === locationCode);
      
      if (!location) {
        toast.error(`Location not found: ${locationCode}`);
        return;
      }

      // Check occupancy
      setCheckingOccupancy(true);
      try {
        const occupancyData = await getLocationOccupancy(location.location_id);
        setOccupancy(occupancyData);
        
        if (occupancyData.active_box_count > 0) {
          // Show warning dialog
          setPendingLocationForOccupancy(location);
          setOccupancyDialogOpen(true);
          setCheckingOccupancy(false);
          return;
        }
      } catch (error) {
        console.error('Failed to check occupancy:', error);
        // Continue anyway if occupancy check fails
      }
      setCheckingOccupancy(false);

      // No occupancy or check failed - proceed normally
      setPendingLocation(location);
      setPendingLocationCode(locationCode);
      setMoveStep(2);
      toast.success(`Location locked: ${locationCode}`);
    } catch (error: any) {
      toast.error(error.response?.data?.detail || error.message || 'Failed to fetch location');
      setCheckingOccupancy(false);
    }
  };

  const handleAssignAnyway = () => {
    if (pendingLocationForOccupancy) {
      setPendingLocation(pendingLocationForOccupancy);
      setPendingLocationCode(pendingLocationForOccupancy.location_code);
      setMoveStep(2);
      
      // Update last scanned info for ScanCoach
      setLastScannedType('location');
      setLastScannedValue(pendingLocationForOccupancy.location_code);
      setWrongScanTypeWarning(null);
      
      setOccupancyDialogOpen(false);
      setPendingLocationForOccupancy(null);
      toast.success(`Location locked: ${pendingLocationForOccupancy.location_code}`);
    }
  };

  const handleScanDifferent = () => {
    setOccupancyDialogOpen(false);
    setPendingLocationForOccupancy(null);
    setOccupancy(null);
    toast('Scan a different location', { icon: 'ℹ️' });
  };

  const handleBoxScan = async (boxId: string) => {
    // #region agent log
    fetch('http://127.0.0.1:7242/ingest/8e87de8d-f5e1-403b-bce8-12dabf8097c0',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'scan/page.tsx:205',message:'handleBoxScan: Called',data:{boxId,mode,isProcessing:processingBoxRef.current.has(boxId)},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'I'})}).catch(()=>{});
    // #endregion
    if (processingBoxRef.current.has(boxId)) {
      return;
    }

    processingBoxRef.current.add(boxId);

    // Fetch box details immediately for preview and duplicate check
    setIsFetchingPreview(true);
    let previewDetails: BoxDetails | null = null;
    try {
      previewDetails = await getBox(boxId);
      setScannedBoxPreview(previewDetails);
      
      // Check for duplicate IN event for INBOUND mode
      // Only check for non-reversed events (undone events should not count as duplicates)
      if (mode === 'INBOUND' && previewDetails.events) {
        const hasInEvent = previewDetails.events.some((e: any) => 
          e.event_type === 'IN' && !e.reversed
        );
        if (hasInEvent) {
          // Box already received - show warning and stop
          setIsFetchingPreview(false);
          processingBoxRef.current.delete(boxId);
          setCameraActive(false);
          setScannedBoxPreview(null);
          
          toast.error(
            `Box ${boxId} was already received!`,
            { 
              icon: '⚠️',
              duration: 5000,
              style: {
                background: '#fef2f2',
                color: '#991b1b',
                border: '2px solid #dc2626',
                fontSize: '16px',
                fontWeight: '600',
                padding: '16px',
              }
            }
          );
          
          // Show the box details so user can see it was already scanned
          setBoxDetails(previewDetails);
          return;
        }
      }
    } catch (error) {
      console.error('Failed to fetch box preview:', error);
    } finally {
      setIsFetchingPreview(false);
    }

    try {
      let event: Event;

      if (mode === 'MOVE') {
        if (!pendingLocationCode) {
          toast.error('Please scan location first');
          processingBoxRef.current.delete(boxId);
          return;
        }
        event = await createEvent({
          event_type: 'MOVE',
          box_id: boxId,
          location_code: pendingLocationCode,
          mode: 'MOVE',
        });
      } else if (mode === 'INBOUND') {
        event = await createEvent({
          event_type: 'IN',
          box_id: boxId,
          mode: 'INBOUND',
        });
      } else {
        event = await createEvent({
          event_type: 'OUT',
          box_id: boxId,
          mode: 'OUTBOUND',
        });
      }

      // CRITICAL: Set lastEvent and preserve mode
      // This ensures the confirmation card stays visible
      shouldPreserveConfirmationRef.current = true;
      
      // #region agent log
      fetch('http://127.0.0.1:7242/ingest/8e87de8d-f5e1-403b-bce8-12dabf8097c0',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'scan/page.tsx:269',message:'handleBoxScan: Setting lastEvent',data:{eventId:event.event_id,eventMode:event.mode,currentMode:mode,shouldPreserve:shouldPreserveConfirmationRef.current},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'A'})}).catch(()=>{});
      // #endregion
      
      // CRITICAL: Ensure mode is ALWAYS set when we have an event
      // Set mode synchronously to prevent race conditions and conflicts with useEffect
      // Always set mode (even if already set) to ensure it matches the event
      if (event.mode) {
        const restoredMode = event.mode === 'INBOUND' ? 'INBOUND' : 
                            event.mode === 'OUTBOUND' ? 'OUTBOUND' : 
                            event.mode === 'MOVE' ? 'MOVE' : null;
        if (restoredMode) {
          // Always set mode to ensure it matches the event, preventing conflicts
          setMode(restoredMode);
        }
      }
      
      // CRITICAL: Stop camera IMMEDIATELY after successful scan
      // This ensures camera stops right away and confirmation card can be shown
      setCameraActive(false);
      
      // CRITICAL: Set lastEvent synchronously
      // React 18 automatically batches state updates in event handlers
      // Setting both mode (above) and lastEvent here ensures they're batched together
      setLastEvent(event);
      setLastEventId(event.event_id);
      
      // Update last scanned info for ScanCoach
      setLastScannedType('box');
      setLastScannedValue(boxId);

      // Use preview details if available, otherwise fetch
      if (scannedBoxPreview && scannedBoxPreview.box_id === boxId) {
        setBoxDetails(scannedBoxPreview);
        // Clear preview after using it
        setScannedBoxPreview(null);
      } else {
        try {
          const details = await getBox(boxId);
          setBoxDetails(details);
        } catch (error) {
          console.error('Failed to fetch box details:', error);
        }
        // Clear preview if we fetched details separately
        setScannedBoxPreview(null);
      }

      // Stats will auto-refresh via useStats hook

      if (event.is_duplicate) {
        // Show prominent error for duplicate
        toast.error(
          `⚠️ This box was already scanned!`,
          { 
            icon: '⚠️',
            duration: 6000,
            style: {
              background: '#fef2f2',
              color: '#991b1b',
              border: '2px solid #dc2626',
              fontSize: '16px',
              fontWeight: '600',
              padding: '16px',
            }
          }
        );
        
        // Still show box details so user can see what was scanned
        // Use preview details if available, otherwise fetch
        if (previewDetails && previewDetails.box_id === boxId) {
          setBoxDetails(previewDetails);
        } else {
          try {
            const details = await getBox(boxId);
            setBoxDetails(details);
          } catch (error) {
            console.error('Failed to fetch box details:', error);
          }
        }
      } else {
        // Show appropriate message based on changed field
        if (event.changed === false) {
          // Box already at this location
          const locationName = pendingLocation?.location_code || 'this location';
          toast(`Already in ${locationName}. No changes made.`, { icon: 'ℹ️' });
        } else {
          // Successful operation
          const locationName = pendingLocation?.location_code || 'location';
          if (mode === 'MOVE') {
            toast.success(`Moved to ${locationName}`);
          } else {
            toast.success(event.message || 'Event created successfully');
          }
        }
      }

      if (event.warning) {
        toast(event.warning, { icon: '⚠️', duration: 5000 });
      }

      // Note: Don't reset MOVE mode state here - keep it for the confirmation card
      // It will be reset when the user dismisses the confirmation card or starts a new scan
    } catch (error: any) {
      const errorMessage = error.response?.data?.detail || error.message || 'Failed to create event';
      toast.error(errorMessage);
      // Clear preview on error
      setScannedBoxPreview(null);
    } finally {
      setTimeout(() => {
        processingBoxRef.current.delete(boxId);
      }, 5000);
    }
  };

  const handleUndo = async () => {
    if (!lastEventId) {
      toast.error('No action to undo');
      return;
    }

    try {
      const response = await undoEvent(lastEventId);
      toast.success('Action undone successfully');
      
      // Immediately refresh stats to reflect the undo
      await refreshStats();
      
      // Small delay to ensure backend has processed the update
      await new Promise(resolve => setTimeout(resolve, 100));
      
      // Clear state
    setLastEvent(null);
    setLastEventId(null);
    setBoxDetails(null);
    setScannedBoxPreview(null);
    setLastScannedType(null);
    setLastScannedValue(null);
    setWrongScanTypeWarning(null);

      // Force a router refresh to update any cached inventory data
      router.refresh();
    } catch (error: any) {
      const errorMessage = error.response?.data?.detail || error.message || 'Failed to undo event';
      toast.error(errorMessage);
    }
  };

  const clearPendingLocation = () => {
    setPendingLocation(null);
    setPendingLocationCode(null);
    setMoveStep(1);
    setLastScannedType(null);
    setLastScannedValue(null);
    setWrongScanTypeWarning(null);
    toast('Location cleared', { icon: 'ℹ️' });
  };

  const handleBackToActions = () => {
    // #region agent log
    fetch('http://127.0.0.1:7242/ingest/8e87de8d-f5e1-403b-bce8-12dabf8097c0',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({location:'scan/page.tsx:428',message:'handleBackToActions: Called',data:{shouldPreserve:shouldPreserveConfirmationRef.current},timestamp:Date.now(),sessionId:'debug-session',runId:'run1',hypothesisId:'F'})}).catch(()=>{});
    // #endregion
    // Only clear if user explicitly clicks back (not from auto-refresh or other triggers)
    // Check if we should preserve the confirmation card
    if (!shouldPreserveConfirmationRef.current) {
      shouldPreserveConfirmationRef.current = false;
      setLastEvent(null);
      setLastEventId(null);
      setBoxDetails(null);
      setScannedBoxPreview(null);
      setMode(null);
      setCameraActive(false);
      setPendingLocation(null);
      setPendingLocationCode(null);
      setMoveStep(1);
    } else {
      // If we're preserving, just clear the preserve flag but keep lastEvent
      // This allows the user to explicitly dismiss it
      shouldPreserveConfirmationRef.current = false;
    }
  };

  // Show action selection screen
  // CRITICAL: If we have a lastEvent, NEVER show home - always show scan interface with confirmation card
  // Only show home if mode is null AND there's no lastEvent
  // ABSOLUTE CHECK: If lastEvent exists, we MUST show scan interface, never home
  const hasLastEvent = !!lastEvent;
  
  // Only show home if BOTH mode is null AND there's no lastEvent
  // If lastEvent exists, we must show scan interface (which will show confirmation card)
  // Note: The useEffect will restore mode from lastEvent if needed
  if (!mode && !hasLastEvent) {
    // Create action cards with proper ordering and urgency
      const receiveCard = (
        <ActionCard
          key="receive"
          title="Receive"
          subtitle="Scan incoming boxes"
          description="When a delivery arrives, scan each box QR code to register it in the system. Boxes will be placed in Receiving Area first."
          icon={Download}
          onClick={() => handleModeSelect('INBOUND')}
          iconColor="text-blue-600"
        />
      );

      const moveCard = (
        <ActionCard
          key="move"
          title="Move"
          subtitle="Put boxes on shelves"
          description="Move boxes from Receiving Area to their permanent shelf locations. Scan location QR first, then scan the box QR code."
          icon={Move}
          onClick={() => handleModeSelect('MOVE')}
          iconColor="text-green-600"
          isUrgent={toPutAway > 0}
        />
      );

      const outgoingCard = (
        <ActionCard
          key="outgoing"
          title="Outgoing"
          subtitle="Scan boxes to ship"
          description="When shipping boxes out, scan the box QR code to mark it as shipped and remove it from inventory."
          icon={Upload}
          onClick={() => handleModeSelect('OUTBOUND')}
          iconColor="text-red-600"
        />
      );

    // Reorder cards: Move first if urgent, otherwise standard order
    const actionCards = toPutAway > 0
      ? [moveCard, receiveCard, outgoingCard]
      : [receiveCard, moveCard, outgoingCard];

    return (
      <PageTransition>
        <div className="max-w-7xl mx-auto space-y-4 sm:space-y-6">
          <PageHeader
            title="Operator Home"
            subtitle="Status board and action console for warehouse operations"
          />
          
          <WorkStatusBanner 
            onStartMove={() => handleModeSelect('MOVE')}
          />
          
          <WorkflowMetrics onWaitingClick={() => handleModeSelect('MOVE')} />
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 sm:gap-4 md:gap-6 mb-4 sm:mb-6 md:mb-8">
            {actionCards}
          </div>
          
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-3 sm:gap-4 md:gap-6 mb-4 sm:mb-6 md:mb-8">
            <div className="lg:col-span-2">
              <PutawayTaskList onPutAway={() => handleModeSelect('MOVE')} />
            </div>
            <div>
              <RecentActivityFeed />
            </div>
          </div>
        </div>
      </PageTransition>
    );
  }

  // Show scanning interface
  // If we have lastEvent, show the confirmation card (it will be rendered below)
  // Use mode from lastEvent if mode is null
  const currentMode = mode || (lastEvent?.mode === 'INBOUND' ? 'INBOUND' : 
                               lastEvent?.mode === 'OUTBOUND' ? 'OUTBOUND' : 
                               lastEvent?.mode === 'MOVE' ? 'MOVE' : null);
  const modeTitle = currentMode === 'INBOUND' ? 'Receive' : currentMode === 'OUTBOUND' ? 'Outgoing' : currentMode === 'MOVE' ? 'Move' : (lastEvent ? 'Scan Complete' : 'Select Action');
  const modeSubtitle = currentMode === 'INBOUND' 
    ? 'Scan box QR codes to register incoming deliveries'
    : currentMode === 'OUTBOUND'
    ? 'Scan box QR codes to ship boxes out'
    : currentMode === 'MOVE'
    ? 'Scan location first, then box QR codes to relocate'
    : lastEvent
    ? 'Review your scan result below'
    : 'Select an action to begin';

  return (
    <PageTransition>
      <div className="max-w-4xl mx-auto space-y-4 sm:space-y-6">
        <PageHeader
          title={modeTitle}
          subtitle={modeSubtitle}
        >
          <div className="flex items-center gap-3">
            {lastEventId && (
              <motion.button
                onClick={handleUndo}
                className={cn(
                  'flex items-center gap-2 px-4 py-2.5 bg-amber-500 text-white rounded-xl',
                  'hover:bg-amber-600 transition-colors text-sm font-semibold shadow-lg hover:shadow-xl'
                )}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                initial={{ opacity: 0, x: 10 }}
                animate={{ opacity: 1, x: 0 }}
              >
                <RotateCcw className="w-4 h-4" />
                Undo
              </motion.button>
            )}
          <motion.button
            onClick={handleBackToActions}
              className={cn(
                'flex items-center gap-1.5 sm:gap-2 px-3 sm:px-4 py-2 sm:py-2.5 text-slate-600 hover:text-slate-900',
                'transition-colors rounded-lg sm:rounded-xl hover:bg-slate-100 text-xs sm:text-sm font-semibold min-h-[44px]'
              )}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
              <ArrowLeft className="w-4 h-4" />
              Back
          </motion.button>
        </div>
        </PageHeader>

        {/* Location Occupancy Dialog */}
        <LocationOccupancyDialog
          open={occupancyDialogOpen}
          onClose={() => {
            setOccupancyDialogOpen(false);
            setPendingLocationForOccupancy(null);
          }}
          onAssignAnyway={handleAssignAnyway}
          onScanDifferent={handleScanDifferent}
          occupancy={occupancy}
          loading={checkingOccupancy}
        />

        {/* Show confirmation card if we have a last event, regardless of camera state */}
        {/* CRITICAL: This card should always show when lastEvent exists, and stay visible */}
        {/* Position it prominently and make it large */}
        {lastEvent && (
          <div className="mb-4 sm:mb-6 flex justify-center w-full">
            <div className="w-full max-w-4xl">
              <AnimatePresence mode="wait">
                <motion.div
                  key="confirmation-card"
                  initial={{ opacity: 0, y: 20, scale: 0.95 }}
                  animate={{ opacity: 1, y: 0, scale: 1 }}
                  exit={{ opacity: 0, y: -20, scale: 0.95 }}
                  transition={{ duration: 0.3, type: 'spring', stiffness: 200 }}
                >
                  <ScanConfirmationCard
              event={lastEvent || undefined}
              boxDetails={boxDetails || undefined}
              location={pendingLocation || undefined}
              onScanAgain={() => {
                // Clear current scan results when user clicks "Scan Again"
                shouldPreserveConfirmationRef.current = false;
                setLastEvent(null);
                setLastEventId(null);
                setBoxDetails(null);
                setScannedBoxPreview(null);
                // Reset MOVE mode state if needed
                if (mode === 'MOVE') {
                  setPendingLocation(null);
                  setPendingLocationCode(null);
                  setMoveStep(1);
                }
                // Clear scan state
                setLastScannedType(null);
                setLastScannedValue(null);
                setWrongScanTypeWarning(null);
                // Restart camera
                setCameraActive(true);
              }}
              onUndo={async () => {
                if (!lastEventId) {
                  toast.error('No action to undo');
                  return;
                }
                try {
                  const response = await undoEvent(lastEventId);
                  toast.success('Action undone successfully');
                  
                  // Immediately refresh stats to reflect the undo
                  await refreshStats();
                  
                  // Small delay to ensure backend has processed the update
                  await new Promise(resolve => setTimeout(resolve, 100));
                  
                  // Clear the event so card disappears
                  shouldPreserveConfirmationRef.current = false;
                  setLastEvent(null);
                  setLastEventId(null);
                  setBoxDetails(null);
                  setScannedBoxPreview(null);
                  
                  // Force a router refresh to update any cached inventory data
                  router.refresh();
                } catch (error: any) {
                  const errorMessage = error.response?.data?.detail || error.message || 'Failed to undo event';
                  toast.error(errorMessage);
                }
              }}
              onBack={handleBackToActions}
            />
              </motion.div>
            </AnimatePresence>
            </div>
          </div>
        )}

        {/* Live Preview Overlay - Show product info while scanning */}
        <AnimatePresence>
          {cameraActive && scannedBoxPreview && !lastEvent && (
            <motion.div
              className="absolute top-20 left-1/2 transform -translate-x-1/2 z-20 bg-white/95 backdrop-blur-sm rounded-xl shadow-2xl border-2 border-blue-200 p-4 sm:p-6 max-w-sm w-[90%]"
              initial={{ opacity: 0, y: -20, scale: 0.9 }}
              animate={{ opacity: 1, y: 0, scale: 1 }}
              exit={{ opacity: 0, y: -20, scale: 0.9 }}
              transition={{ type: 'spring', stiffness: 300, damping: 25 }}
            >
              <div className="text-center">
                <div className="text-xs sm:text-sm font-semibold text-blue-600 mb-2 uppercase tracking-wide">
                  Scanned Box
                </div>
                <div className="text-lg sm:text-xl md:text-2xl font-bold text-slate-900 mb-1">
                  {scannedBoxPreview.product.brand}
                </div>
                <div className="text-base sm:text-lg text-slate-700 font-semibold mb-2">
                  {scannedBoxPreview.product.name}
                </div>
                {scannedBoxPreview.product.size && (
                  <div className="text-sm text-slate-600 mb-2">
                    Size: {scannedBoxPreview.product.size}
                  </div>
                )}
                <div className="text-xs sm:text-sm font-mono text-slate-500 bg-slate-50 px-3 py-1.5 rounded-lg inline-block">
                  {scannedBoxPreview.box_id}
                </div>
                {isFetchingPreview && (
                  <div className="mt-2 text-xs text-slate-500">Processing...</div>
                )}
              </div>
            </motion.div>
          )}
        </AnimatePresence>

        {/* Only show camera when active AND no lastEvent (confirmation card should be shown instead) */}
        {cameraActive && !lastEvent ? (
          <motion.div
            className="mb-8 relative min-h-[400px]"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: 0.2, duration: 0.3 }}
          >
            <QRScanner
              active={cameraActive}
              expectedPrefix={mode === 'MOVE' ? (moveStep === 1 ? 'LOC:' : 'BOX:') : 'BOX:'}
              onScanSuccess={(value, type) => {
                // Clear wrong scan type warning on successful scan
                setWrongScanTypeWarning(null);
                setLastScannedType(type);
                setLastScannedValue(value);
                
                if (mode === 'MOVE') {
                  if (moveStep === 1) {
                    handleLocationScan(value);
                  } else {
                    handleBoxScan(value);
                  }
                } else {
                  handleBoxScan(value);
                }
              }}
              onWrongType={(expected, received) => {
                setWrongScanTypeWarning({ expected, received });
                setLastScannedType(received);
                // Don't clear lastScannedValue - we might want to show what was scanned
              }}
              onScanError={(error) => {
                toast.error(error);
              }}
            />
            <motion.button
              onClick={handleStopCamera}
              className="absolute top-4 right-4 px-4 py-2.5 bg-red-500 text-white rounded-xl hover:bg-red-600 flex items-center gap-2 shadow-xl z-10 font-semibold"
              whileHover={{ scale: 1.05 }}
              whileTap={{ scale: 0.98 }}
            >
              <XCircle className="w-4 h-4" />
              Stop Camera
            </motion.button>
          </motion.div>
        ) : !lastEvent ? (
          <motion.div
            className="bg-white p-4 sm:p-6 md:p-8 rounded-xl sm:rounded-2xl shadow-lg border border-slate-200 mb-4 sm:mb-6"
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ duration: 0.3 }}
          >
            <div className="text-center mb-6">
              <h3 className="text-base sm:text-lg md:text-xl font-bold text-slate-900 mb-1.5 sm:mb-2">
                {mode === 'MOVE' && moveStep === 1
                  ? 'Ready to scan location QR code'
                  : mode === 'MOVE' && moveStep === 2
                  ? 'Ready to scan box QR code'
                  : mode === 'INBOUND'
                  ? 'Ready to scan box QR code'
                  : 'Ready to scan box QR code'}
              </h3>
              <p className="text-sm sm:text-base text-slate-600">
                {mode === 'MOVE' && moveStep === 1
                  ? 'Find the location QR code on the shelf where you want to place the box'
                  : mode === 'MOVE' && moveStep === 2
                  ? 'Find the box QR code on the label of the box you want to move'
                  : mode === 'INBOUND'
                  ? 'Find the box QR code on the label of the box you received'
                  : 'Find the box QR code on the label of the box you want to ship'}
              </p>
            </div>

            {/* Visual Example */}
            <div className="bg-slate-50 rounded-xl p-6 border border-slate-200 mb-4">
              <div className="flex items-center justify-center gap-8 mb-4">
                <div className="text-center">
                  <div className="w-24 h-24 bg-white border-2 border-dashed border-slate-300 rounded-lg flex items-center justify-center mb-2 mx-auto">
                    {mode === 'MOVE' && moveStep === 1 ? (
                      <MapPin className="w-12 h-12 text-slate-400" />
                    ) : (
                      <QrCode className="w-12 h-12 text-slate-400" />
                    )}
                  </div>
                  <p className="text-xs font-semibold text-slate-700 mt-2">
                    {mode === 'MOVE' && moveStep === 1 ? 'Location QR' : 'Box QR'}
                  </p>
                </div>
                {mode === 'MOVE' && moveStep === 2 && (
                  <>
                    <ArrowRight className="w-6 h-6 text-slate-400" />
                    <div className="text-center">
                      <div className="w-24 h-24 bg-white border-2 border-dashed border-slate-300 rounded-lg flex items-center justify-center mb-2 mx-auto">
                        <Package className="w-12 h-12 text-slate-400" />
                      </div>
                      <p className="text-xs font-semibold text-slate-700 mt-2">Box QR</p>
                    </div>
                  </>
                )}
              </div>
              <div className="text-center">
                <motion.button
                  onClick={handleStartCamera}
                  className="flex items-center gap-2 px-6 py-3 bg-blue-600 text-white rounded-xl hover:bg-blue-700 font-semibold shadow-lg transition-colors mx-auto"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  <Camera className="w-5 h-5" />
                  Start Camera
                </motion.button>
              </div>
            </div>
          </motion.div>
        ) : null}
      </div>
    </PageTransition>
  );
}
