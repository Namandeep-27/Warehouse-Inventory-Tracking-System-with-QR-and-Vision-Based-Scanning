import { type ClassValue, clsx } from "clsx"
import { twMerge } from "tailwind-merge"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Format location code for display to users
 * Converts system location codes to user-friendly names
 */
export function formatLocationName(locationCode: string): string {
  if (locationCode === 'RECEIVING') {
    return 'Receiving Area';
  }
  return locationCode;
}

/**
 * Format time in Boston timezone (America/New_York)
 * All timestamps should be displayed in Boston time regardless of user's location
 */
export function formatTimeInBostonTime(timestamp: string): string {
  if (!timestamp) return 'Unknown';
  
  try {
    // Parse timestamp - ensure it's treated as UTC if no timezone info
    let timestampStr = timestamp;
    if (!timestampStr.includes('Z') && !timestampStr.includes('+') && !timestampStr.includes('-', 10)) {
      timestampStr = timestampStr + 'Z';
    }
    
    const date = new Date(timestampStr);
    
    // Check if date is valid
    if (isNaN(date.getTime())) {
      return 'Invalid date';
    }
    
    // Format in Boston timezone (America/New_York)
    return date.toLocaleString('en-US', {
      timeZone: 'America/New_York',
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: 'numeric',
      minute: '2-digit',
      hour12: true
    });
  } catch (e) {
    return 'Invalid date';
  }
}

/**
 * Format relative time in Boston timezone (e.g., "5m ago", "2h ago")
 * All relative times should be calculated based on Boston time
 */
export function formatRelativeTimeInBoston(timestamp: string): string {
  if (!timestamp) return 'Unknown';
  
  let timestampStr = timestamp;
  if (!timestampStr.includes('Z') && !timestampStr.includes('+') && !timestampStr.includes('-', 10)) {
    timestampStr = timestampStr + 'Z';
  }
  
  const date = new Date(timestampStr);
  
  // Calculate difference in milliseconds (both dates are UTC internally)
  // Then convert to Boston timezone for display
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSec = Math.floor(diffMs / 1000);
  const diffMin = Math.floor(diffSec / 60);
  const diffHour = Math.floor(diffMin / 60);
  const diffDay = Math.floor(diffHour / 24);
  
  if (diffSec < 60) return 'Just now';
  if (diffMin < 60) return `${diffMin}m ago`;
  if (diffHour < 24) return `${diffHour}h ago`;
  if (diffDay < 7) return `${diffDay}d ago`;
  
  // For older dates, show date and time in Boston timezone
  return date.toLocaleString('en-US', {
    timeZone: 'America/New_York',
    month: 'short',
    day: 'numeric',
    hour: 'numeric',
    minute: '2-digit',
    hour12: true
  });
}
