'use client';

import { motion } from 'framer-motion';
import { cn } from '@/lib/utils';

export type ProductCategory = 'all' | 'whiskey' | 'rum' | 'beer' | 'wine' | 'champagne' | 'vodka' | 'tequila' | 'gin' | 'other';

interface CategoryFilterProps {
  selectedCategory: ProductCategory;
  onCategoryChange: (category: ProductCategory) => void;
  className?: string;
}

const categories: { value: ProductCategory; label: string; emoji?: string }[] = [
  { value: 'all', label: 'All', emoji: '📦' },
  { value: 'whiskey', label: 'Whiskey', emoji: '🥃' },
  { value: 'rum', label: 'Rum', emoji: '🍹' },
  { value: 'beer', label: 'Beer', emoji: '🍺' },
  { value: 'wine', label: 'Wine', emoji: '🍷' },
  { value: 'champagne', label: 'Champagne / Sparkling', emoji: '🍾' },
  { value: 'vodka', label: 'Vodka', emoji: '🍸' },
  { value: 'tequila', label: 'Tequila', emoji: '🥂' },
  { value: 'gin', label: 'Gin', emoji: '🍸' },
  { value: 'other', label: 'Other', emoji: '📦' },
];

export default function CategoryFilter({ selectedCategory, onCategoryChange, className }: CategoryFilterProps) {
  return (
    <div className={cn('flex flex-wrap gap-2', className)}>
      {categories.map((category) => (
        <motion.button
          key={category.value}
          onClick={(e) => {
            e.stopPropagation(); // Prevent click from bubbling to react-select
            onCategoryChange(category.value);
          }}
          className={cn(
            'px-3 sm:px-4 py-2 rounded-lg sm:rounded-xl text-xs sm:text-sm font-semibold transition-all',
            'min-h-[36px] sm:min-h-[40px] flex items-center gap-1.5 sm:gap-2',
            selectedCategory === category.value
              ? 'bg-blue-600 text-white shadow-md'
              : 'bg-slate-100 text-slate-700 hover:bg-slate-200'
          )}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          {category.emoji && <span>{category.emoji}</span>}
          <span>{category.label}</span>
        </motion.button>
      ))}
    </div>
  );
}

// Helper function to normalize text (remove accents, normalize special chars)
function normalizeText(text: string): string {
  return text
    .normalize('NFD') // Decompose accented characters (ë becomes e + combining mark)
    .replace(/[\u0300-\u036f]/g, '') // Remove diacritics (the combining marks)
    .replace(/-/g, ' ') // Hyphens to spaces
    .replace(/&/g, ' and ') // Ampersands to "and"
    .replace(/\s+/g, ' ') // Multiple spaces to single space
    .trim();
}

// Helper function to determine category from product name and brand
export function getProductCategory(productName: string, brandName?: string): ProductCategory {
  const name = normalizeText(productName.toLowerCase());
  const brand = normalizeText((brandName || '').toLowerCase());
  const combined = `${brand} ${name}`;
  
  // Helper to normalize brand names for comparison
  const normalizeBrand = (b: string) => normalizeText(b);
  
  // Check combined brand + name for better detection
  if (combined.includes('whiskey') || combined.includes('whisky') || combined.includes('bourbon') || combined.includes('scotch')) {
    return 'whiskey';
  }
  
  // Check known whiskey brands
  const whiskeyBrands = [
    'johnnie walker', 'jack daniel', 'jameson', 'crown royal', 'makers mark', 
    'woodford', 'buffalo trace', 'wild turkey', 'four roses', 'bulleit',
    'macallan', 'glenfiddich', 'glenlivet', 'lagavulin', 'ardbeg',
    'chivas', 'dewars', 'ballantines', 'famous grouse', 'jim beam',
    'evan williams', 'old forester', 'knob creek', 'basil hayden'
  ];
  if (whiskeyBrands.some(b => brand.includes(normalizeBrand(b)))) {
    return 'whiskey';
  }
  
  // Check known rum brands
  const rumBrands = [
    'bacardi', 'captain morgan', 'malibu', 'mount gay', 'appleton',
    'havana club', 'ron zacapa', 'diplomatico', 'flor de cana',
    'goslings', 'kraken', 'myers', 'pussers', 'rhum barbancourt'
  ];
  if (rumBrands.some(b => brand.includes(normalizeBrand(b)))) {
    return 'rum';
  }
  if (name.includes('rum') || combined.includes('rum')) {
    return 'rum';
  }
  
  // Check known beer brands
  const beerBrands = [
    'budweiser', 'coors', 'miller', 'heineken', 'corona', 'stella artois',
    'guinness', 'samuel adams', 'sierra nevada', 'blue moon', 'dos equis',
    'modelo', 'pabst', 'yuengling', 'new belgium', 'lagunitas', 'dogfish head'
  ];
  if (beerBrands.some(b => brand.includes(normalizeBrand(b)))) {
    return 'beer';
  }
  if (name.includes('beer') || name.includes('ale') || name.includes('lager') || combined.includes('beer')) {
    return 'beer';
  }
  
  // Check known champagne/sparkling brands (check before wine)
  const champagneBrands = [
    'moet', 'dom perignon', 'veuve clicquot', 'prosecco', 'la marca',
    'korbel', 'andre', 'cook', 'freixenet', 'cava', 'asti',
    'mumm', 'taittinger', 'perrier jouet', 'bollinger', 'lanson'
  ];
  if (champagneBrands.some(b => brand.includes(normalizeBrand(b)))) {
    return 'champagne';
  }
  // Check for champagne/sparkling keywords
  if (combined.includes('champagne') || combined.includes('sparkling') || 
      combined.includes('prosecco') || combined.includes('brut') || 
      combined.includes('cava') || combined.includes('moscato') ||
      name.includes('brut') || name.includes('sparkling')) {
    return 'champagne';
  }
  
  // Check known wine brands (still wine only)
  const wineBrands = [
    'yellow tail', 'barefoot', 'sutter home', 'woodbridge', 'kendall jackson',
    'bogle', 'chateau ste michelle', 'robert mondavi', 'beringer',
    'chateau', 'merlot', 'cabernet', 'chardonnay', 'pinot noir', 'sauvignon'
  ];
  if (wineBrands.some(b => brand.includes(normalizeBrand(b)))) {
    return 'wine';
  }
  if (name.includes('wine') || combined.includes('wine')) {
    return 'wine';
  }
  
  // Check known vodka brands
  const vodkaBrands = [
    'absolut', 'grey goose', 'smirnoff', 'ketel one', 'belvedere',
    'tito', 'stolichnaya', 'ciroc', 'svedka', 'new amsterdam',
    'sky', 'finlandia', 'pinnacle', 'deep eddy'
  ];
  if (vodkaBrands.some(b => brand.includes(normalizeBrand(b)))) {
    return 'vodka';
  }
  if (name.includes('vodka') || combined.includes('vodka')) {
    return 'vodka';
  }
  
  // Check known tequila brands
  const tequilaBrands = [
    'jose cuervo', 'patron', 'don julio', 'herradura', 'el jimador',
    'sauza', '1800', 'casamigos', 'clase azul', 'milagro', 'cazadores',
    'hornitos', 'tres agaves', 'lunazul', 'espolon'
  ];
  if (tequilaBrands.some(b => brand.includes(normalizeBrand(b)))) {
    return 'tequila';
  }
  if (name.includes('tequila') || combined.includes('tequila')) {
    return 'tequila';
  }
  
  // Check known gin brands
  const ginBrands = [
    'tanqueray', 'bombay', 'hendricks', 'beefeater', 'gordon',
    'aviation', 'the botanist', 'plymouth', 'sipsmith', 'fords',
    'monkey 47', 'roku', 'st george', 'citadelle'
  ];
  if (ginBrands.some(b => brand.includes(normalizeBrand(b)))) {
    return 'gin';
  }
  if (name.includes('gin') || combined.includes('gin')) {
    return 'gin';
  }
  
  return 'other';
}
