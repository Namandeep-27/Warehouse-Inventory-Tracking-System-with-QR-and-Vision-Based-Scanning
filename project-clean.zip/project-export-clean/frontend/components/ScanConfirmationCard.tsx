'use client';

import { motion, AnimatePresence } from 'framer-motion';
import { CheckCircle, AlertTriangle, MapPin, Camera, RotateCcw, Home, Package, QrCode } from 'lucide-react';
import { Event, Location, BoxDetails, ExceptionType } from '@/lib/types';
import { cn, formatLocationName } from '@/lib/utils';

interface ScanConfirmationCardProps {
  event?: Event | null;
  boxDetails?: BoxDetails | null;
  location?: Location | null;
  onDismiss?: () => void;
  onScanAgain?: () => void;
  onUndo?: () => void;
  onBack?: () => void;
}

export default function ScanConfirmationCard({
  event,
  boxDetails,
  location,
  onDismiss,
  onScanAgain,
  onUndo,
  onBack,
}: ScanConfirmationCardProps) {
  if (!event && !location) return null;

  // For location scans (MOVE step 1)
  if (location && !event) {
    return (
      <AnimatePresence>
        <motion.div
          className="bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-200 rounded-2xl p-6 sm:p-8 md:p-10 lg:p-12 shadow-2xl w-full"
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.95 }}
          transition={{ type: 'spring', stiffness: 200, damping: 20 }}
        >
          <div className="flex items-start gap-6">
                <motion.div
                  className="p-4 sm:p-5 bg-green-100 rounded-xl flex-shrink-0"
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ type: 'spring', stiffness: 200, damping: 15 }}
                >
                  <CheckCircle className="w-12 h-12 sm:w-16 sm:h-16 text-green-600" />
                </motion.div>
            <div className="flex-1">
                  <h3 className="text-lg sm:text-xl md:text-2xl font-bold text-green-900 mb-3 sm:mb-4">Location Scanned</h3>
              <div className="bg-white rounded-xl p-6 border border-green-100 shadow-sm">
                    <div className="text-2xl sm:text-3xl font-bold text-green-900 mb-3 sm:mb-4">{formatLocationName(location.location_code)}</div>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
                  <div>
                    <span className="text-slate-500 block mb-1">Zone</span>
                    <span className="font-semibold text-slate-900">{location.zone}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block mb-1">Aisle</span>
                    <span className="font-semibold text-slate-900">{location.aisle}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block mb-1">Rack</span>
                    <span className="font-semibold text-slate-900">{location.rack}</span>
                  </div>
                  <div>
                    <span className="text-slate-500 block mb-1">Shelf</span>
                    <span className="font-semibold text-slate-900">{location.shelf}</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>
    );
  }

  // For box scans
  if (event && boxDetails) {
    const displayLocation = location || boxDetails.current_location;
    const status = boxDetails.status || 'UNKNOWN';
    const statusColor = status === 'IN_STOCK' ? 'green' : 'gray';
    const statusBg = status === 'IN_STOCK' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800';

    return (
      <AnimatePresence>
        <motion.div
          className="bg-gradient-to-br from-green-50 via-emerald-50 to-teal-50 border-2 border-green-300 rounded-3xl p-6 sm:p-8 md:p-10 lg:p-12 shadow-2xl w-full backdrop-blur-sm"
          initial={{ opacity: 0, y: 20, scale: 0.95 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: -20, scale: 0.95 }}
          transition={{ type: 'spring', stiffness: 200, damping: 20 }}
        >
          <div className="flex items-start gap-6 sm:gap-8">
                <motion.div
                  className="p-5 sm:p-6 bg-gradient-to-br from-green-100 to-emerald-100 rounded-2xl flex-shrink-0 shadow-lg"
                  initial={{ scale: 0, rotate: -180 }}
                  animate={{ scale: 1, rotate: 0 }}
                  transition={{ type: 'spring', stiffness: 200, damping: 15 }}
                >
                  <CheckCircle className="w-14 h-14 sm:w-16 sm:h-16 text-green-600 drop-shadow-md" />
                </motion.div>
            <div className="flex-1 min-w-0">
              <div className="flex items-start justify-between gap-4 mb-6 sm:mb-8 pb-6 sm:pb-8 border-b-2 border-green-200/50">
                <div className="flex-1 min-w-0">
                      <div className="inline-block bg-green-100/50 px-3 py-1 rounded-full mb-3">
                        <span className="text-xs font-semibold text-green-700 uppercase tracking-wider">Scanned</span>
                      </div>
                      <h3 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-extrabold text-green-900 mb-2 sm:mb-3 leading-tight">
                        {event.product.brand}
                      </h3>
                      <p className="text-lg sm:text-xl md:text-2xl lg:text-3xl text-green-700 font-semibold">{event.product.name}</p>
                </div>
                <div className={cn(
                  'px-5 py-3 rounded-2xl text-sm font-bold uppercase tracking-wide shadow-lg flex items-center gap-2',
                  status === 'IN_STOCK' ? 'bg-green-500 text-white' : 'bg-gray-500 text-white'
                )}>
                  <CheckCircle className="w-5 h-5" />
                  {status.replace('_', ' ')}
                </div>
              </div>

              <div className="bg-white/80 backdrop-blur-sm rounded-xl p-5 sm:p-6 md:p-8 border-2 border-green-100/50 shadow-lg space-y-4 mb-6 sm:mb-8">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {event.product.size && (
                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
                      <div className="p-2 bg-blue-100 rounded-lg">
                        <Package className="w-5 h-5 text-blue-600" />
                      </div>
                      <div>
                        <span className="text-xs text-slate-500 font-medium block">Size</span>
                        <span className="font-bold text-slate-900">{event.product.size}</span>
                      </div>
                    </div>
                  )}
                  {event.lot_code && (
                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
                      <div className="p-2 bg-purple-100 rounded-lg">
                        <QrCode className="w-5 h-5 text-purple-600" />
                      </div>
                      <div>
                        <span className="text-xs text-slate-500 font-medium block">Lot Code</span>
                        <span className="font-bold text-slate-900 font-mono">{event.lot_code}</span>
                      </div>
                    </div>
                  )}
                  <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
                    <div className="p-2 bg-green-100 rounded-lg">
                      <Package className="w-5 h-5 text-green-600" />
                    </div>
                    <div>
                      <span className="text-xs text-slate-500 font-medium block">Box ID</span>
                      <span className="font-bold text-slate-900 font-mono text-base sm:text-lg">{event.box_id}</span>
                    </div>
                  </div>
                  {displayLocation && (
                    <div className="flex items-center gap-3 p-3 bg-slate-50 rounded-lg">
                      <div className="p-2 bg-amber-100 rounded-lg">
                        <MapPin className="w-5 h-5 text-amber-600" />
                      </div>
                      <div>
                        <span className="text-xs text-slate-500 font-medium block">Location</span>
                        <span className="font-bold text-slate-900">{formatLocationName(displayLocation.location_code)}</span>
                      </div>
                    </div>
                  )}
                </div>
              </div>

              {event.is_duplicate && (
                <motion.div
                  className="bg-red-50 border-2 border-red-300 rounded-xl p-4 mb-4"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="w-5 h-5 text-red-600 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-base font-bold text-red-900 mb-1">
                        ⚠️ This box was already scanned!
                      </p>
                      <p className="text-sm text-red-700">
                        This box has already been received. No new event was created.
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}

              {event.exception_type && !event.is_duplicate && (
                <motion.div
                  className="bg-amber-50 border-2 border-amber-200 rounded-xl p-4 mb-4"
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: 0.2 }}
                >
                  <div className="flex items-start gap-3">
                    <AlertTriangle className="w-5 h-5 text-amber-600 flex-shrink-0 mt-0.5" />
                    <div className="flex-1">
                      <p className="text-sm font-semibold text-amber-900">
                        {event.exception_type === 'OUT_WITHOUT_IN'
                          ? 'Warning: Box was never received (no IN event found)'
                          : event.warning || `Exception: ${event.exception_type}`}
                      </p>
                    </div>
                  </div>
                </motion.div>
              )}

              {event.warning && !event.exception_type && (
                <div className="bg-blue-50 border-2 border-blue-200 rounded-xl p-4">
                  <p className="text-sm font-medium text-blue-900">{event.warning}</p>
                </div>
              )}

                  <div className="mt-6 sm:mt-8 flex flex-col sm:flex-row gap-3 sm:gap-4">
                    {onScanAgain && (
                      <motion.button
                        onClick={onScanAgain}
                        className="flex-1 py-4 sm:py-5 bg-gradient-to-r from-green-600 to-emerald-600 text-white rounded-xl sm:rounded-2xl hover:from-green-700 hover:to-emerald-700 transition-all text-base sm:text-lg md:text-xl font-bold shadow-xl hover:shadow-2xl min-h-[56px] sm:min-h-[64px] flex items-center justify-center gap-3 transform hover:scale-105"
                        whileHover={{ scale: 1.05 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <Camera className="w-6 h-6 sm:w-7 sm:h-7" />
                        Scan Again
                      </motion.button>
                    )}
                    {onUndo && (
                      <motion.button
                        onClick={onUndo}
                        className="flex-1 py-4 sm:py-5 bg-gradient-to-r from-amber-600 to-orange-600 text-white rounded-xl sm:rounded-2xl hover:from-amber-700 hover:to-orange-700 transition-all text-base sm:text-lg md:text-xl font-bold shadow-xl hover:shadow-2xl min-h-[56px] sm:min-h-[64px] flex items-center justify-center gap-3"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <RotateCcw className="w-6 h-6 sm:w-7 sm:h-7" />
                        Undo
                      </motion.button>
                    )}
                    {onBack && (
                      <motion.button
                        onClick={onBack}
                        className="flex-1 py-4 sm:py-5 bg-gradient-to-r from-slate-600 to-slate-700 text-white rounded-xl sm:rounded-2xl hover:from-slate-700 hover:to-slate-800 transition-all text-base sm:text-lg md:text-xl font-bold shadow-xl hover:shadow-2xl min-h-[56px] sm:min-h-[64px] flex items-center justify-center gap-3"
                        whileHover={{ scale: 1.02 }}
                        whileTap={{ scale: 0.98 }}
                      >
                        <Home className="w-6 h-6 sm:w-7 sm:h-7" />
                        Back
                      </motion.button>
                    )}
                  </div>
            </div>
          </div>
        </motion.div>
      </AnimatePresence>
    );
  }

  return null;
}
