"""Inventory router."""
from fastapi import APIRouter, HTTPException
from typing import List, Optional
from app.models import InventoryItem
from app.database import supabase
from datetime import datetime, timezone, timedelta
from zoneinfo import ZoneInfo

router = APIRouter(prefix="/inventory", tags=["inventory"])


@router.get("")
async def get_inventory(
    status: Optional[str] = None,
    location_id: Optional[str] = None,
    search: Optional[str] = None,
    event_type_today: Optional[str] = None,  # "IN", "MOVE", or "OUT"
    date_from: Optional[str] = None,  # ISO date string (YYYY-MM-DD)
    date_to: Optional[str] = None  # ISO date string (YYYY-MM-DD)
):
    """Get inventory list with product info."""
    try:
        # If filtering by event type today, get box_ids from events first
        box_ids_from_events = None
        if event_type_today:
            # Get start and end of today in Boston timezone (America/New_York)
            boston_tz = ZoneInfo("America/New_York")
            now_boston = datetime.now(boston_tz)
            today_boston = now_boston.date()
            today_start_boston = datetime.combine(today_boston, datetime.min.time(), tzinfo=boston_tz)
            tomorrow_start_boston = today_start_boston + timedelta(days=1)
            
            # Convert to UTC for database query (PostgreSQL timestamps are typically UTC)
            today_start_utc = today_start_boston.astimezone(timezone.utc)
            tomorrow_start_utc = tomorrow_start_boston.astimezone(timezone.utc)
            
            today_start_str = today_start_utc.isoformat()
            tomorrow_start_str = tomorrow_start_utc.isoformat()
            
            # Query events for today with this event type
            try:
                events_result = supabase.table("events").select("box_id").eq("event_type", event_type_today).eq("reversed", False).gte("timestamp", today_start_str).lt("timestamp", tomorrow_start_str).execute()
            except Exception:
                # Fallback if reversed column doesn't exist
                events_result = supabase.table("events").select("box_id").eq("event_type", event_type_today).gte("timestamp", today_start_str).lt("timestamp", tomorrow_start_str).execute()
            
            box_ids_from_events = set(event["box_id"] for event in events_result.data)
            if not box_ids_from_events:
                return []  # No events today, return empty list
        
        # Build query
        query = supabase.table("inventory_state").select("*")
        
        if status:
            query = query.eq("status", status)
        
        if location_id:
            query = query.eq("current_location_id", location_id)
        
        result = query.execute()
        
        if not result.data:
            return []
        
        # Filter by event type today first if needed
        filtered_items = result.data
        if box_ids_from_events is not None:
            filtered_items = [item for item in filtered_items if item["box_id"] in box_ids_from_events]
        
        if not filtered_items:
            return []
        
        # Batch fetch all boxes, products, and locations to avoid N+1 queries
        box_ids = [item["box_id"] for item in filtered_items]
        boxes_result = supabase.table("boxes").select("*").in_("box_id", box_ids).execute()
        boxes_dict = {box["box_id"]: box for box in boxes_result.data} if boxes_result.data else {}
        
        # Get all product IDs
        product_ids = list(set(box.get("product_id") for box in boxes_dict.values() if box.get("product_id")))
        products_dict = {}
        if product_ids:
            products_result = supabase.table("products").select("*").in_("product_id", product_ids).execute()
            products_dict = {p["product_id"]: p for p in products_result.data} if products_result.data else {}
        
        # Get all location IDs
        location_ids = list(set(item.get("current_location_id") for item in filtered_items if item.get("current_location_id")))
        locations_dict = {}
        if location_ids:
            locs_result = supabase.table("locations").select("*").in_("location_id", location_ids).execute()
            locations_dict = {l["location_id"]: l for l in locs_result.data} if locs_result.data else {}
        
        # Build inventory list with batched data
        inventory = []
        for item in filtered_items:
            box_data = boxes_dict.get(item["box_id"])
            if not box_data:
                continue
            
            product = products_dict.get(box_data.get("product_id"))
            if not product:
                continue
            
            location = None
            if item.get("current_location_id"):
                location = locations_dict.get(item["current_location_id"])
            
            # Apply search filter if provided
            if search:
                search_lower = search.lower()
                if (search_lower not in item["box_id"].lower() and
                    search_lower not in product.get("brand", "").lower() and
                    search_lower not in product.get("name", "").lower()):
                    continue
            
            # Apply date filter if provided (filter by last_event_time)
            if date_from or date_to:
                last_event_time = item.get("last_event_time")
                if not last_event_time:
                    continue  # Skip items without last_event_time
                
                # Parse last_event_time and convert to local timezone for date comparison
                # This ensures "Today" and "Yesterday" match user expectations
                try:
                    # Get Boston timezone (same as stats endpoint)
                    boston_tz = ZoneInfo("America/New_York")
                    
                    # Parse last_event_time (assume it's ISO format, typically UTC)
                    if 'T' in str(last_event_time) or '+' in str(last_event_time) or 'Z' in str(last_event_time):
                        # Parse as UTC if it has timezone info
                        event_time_utc = datetime.fromisoformat(str(last_event_time).replace('Z', '+00:00'))
                        if event_time_utc.tzinfo is None:
                            # If no timezone, assume UTC
                            event_time_utc = event_time_utc.replace(tzinfo=timezone.utc)
                        # Convert to Boston timezone
                        event_time_boston = event_time_utc.astimezone(boston_tz)
                        event_date = event_time_boston.date()
                    else:
                        # If it's just a date string, parse it directly
                        event_date = datetime.fromisoformat(str(last_event_time)).date()
                    
                    # Parse date filters (these should be YYYY-MM-DD format, representing local dates)
                    if date_from:
                        from_date = datetime.strptime(date_from, '%Y-%m-%d').date()
                        if event_date < from_date:
                            continue
                    
                    if date_to:
                        to_date = datetime.strptime(date_to, '%Y-%m-%d').date()
                        if event_date > to_date:
                            continue
                except (ValueError, AttributeError) as e:
                    # If parsing fails, skip this item
                    continue
            
            inventory.append({
                "box_id": item["box_id"],
                "status": item["status"],
                "current_location": location,
                "last_event_time": item.get("last_event_time"),
                "product": {
                    "brand": product["brand"],
                    "name": product["name"],
                    "size": product.get("size")
                },
                "lot_code": box_data.get("lot_code")
            })
        
        return inventory
    
    except Exception as e:
        import traceback
        traceback.print_exc()
        raise HTTPException(status_code=500, detail=str(e))
